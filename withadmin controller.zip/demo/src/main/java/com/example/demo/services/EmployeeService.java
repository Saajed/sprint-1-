package com.example.demo.services;

import com.example.demo.repository.ClientRepository;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.entities.Client;
import com.example.demo.entities.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {
    @Autowired 
    private  EmployeeRepository employeeRepository;
    @Autowired
    private  ClientRepository clientRepository;


    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee updateEmployee(Long id, Employee updatedEmployee) {
        return employeeRepository.findById(id).map(employee -> {
            employee.setNom(updatedEmployee.getNom());
            employee.setPrenom(updatedEmployee.getPrenom());
            employee.setEmail(updatedEmployee.getEmail());
            employee.setPoste(updatedEmployee.getPoste());
            return employeeRepository.save(employee);
        }).orElseThrow(() -> new RuntimeException("Employee not found"));
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

 
    public Employee assignClientToEmployee(Long employeeId, Long clientId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employé non trouvé"));
        Client client = clientRepository.findById(clientId)
                .orElseThrow(() -> new RuntimeException("Client non trouvé"));

        employee.getAssignedClients().add(client);
        return employeeRepository.save(employee);
    }
}

package com.example.demo.services;

import com.example.demo.entities.Form;
import com.example.demo.repository.FormRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FormService {

    @Autowired
    private FormRepository formRepository;

    public List<Form> getAllForms() {
        return formRepository.findAll();
    }

    public List<Form> getFormsByClientId(Long clientId) {
        return formRepository.findByClientId(clientId);
    }

    public Form saveForm(Form form) {
        form.setDateDerniereModification(java.time.LocalDateTime.now());
        return formRepository.save(form);
    }

    public void deleteForm(Long id) {
        formRepository.deleteById(id);
    }
}
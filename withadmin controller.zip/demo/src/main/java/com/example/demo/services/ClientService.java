package com.example.demo.services;

import com.example.demo.entities.Client;
import com.example.demo.repository.ClientRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClientService {
    @Autowired
    private  ClientRepository clientrepository;

    public ClientService(ClientRepository clientrepository) {
        this.clientrepository = clientrepository;
    }

    // FIND client par son email
    public Optional<Client> findByEmail(String email) {
        return clientrepository.findByEmail(email);
    }

    // GET clients
    public List<Client> getAllClients() {
        return clientrepository.findAll();
    }

    // GET client par son ID
    public Optional<Client> getClientById(Long id) {
        return clientrepository.findById(id);
    }

    // ADD client
    public Client createClient(Client client) {
        return clientrepository.save(client);
    }



    // DEDLETE client
    public void deleteClient(Long id) {
        clientrepository.deleteById(id);
    }
}


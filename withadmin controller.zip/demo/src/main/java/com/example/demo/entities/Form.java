package com.example.demo.entities;

import com.example.demo.entities.Statut;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter 
@Setter
@ToString
@Builder
@Table(name = "form")
public class Form {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime dateDeCreation;
    private LocalDateTime dateDerniereModification;
    private String but;
    
    @Enumerated(EnumType.STRING)
    private Statut statut ; 

    @ManyToOne
    @JoinColumn(name = "client_id", nullable = false)
    private Client client;

    public Form() {
        this.dateDeCreation = LocalDateTime.now();
        this.dateDerniereModification = LocalDateTime.now();
    }

    public Form(Statut Statut, Client Client) {
        this.dateDeCreation = LocalDateTime.now();
        this.dateDerniereModification = LocalDateTime.now();
        this.statut = statut;
        this.client = client;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public LocalDateTime getDateDeCreation() {
		return dateDeCreation;
	}

	public void setDateDeCreation(LocalDateTime dateDeCreation) {
		this.dateDeCreation = dateDeCreation;
	}

	public LocalDateTime getDateDerniereModification() {
		return dateDerniereModification;
	}

	public void setDateDerniereModification(LocalDateTime dateDerniereModification) {
		this.dateDerniereModification = dateDerniereModification;
	}

	public String getBut() {
		return but;
	}

	public void setBut(String but) {
		this.but = but;
	}

	public Statut getStatut() {
		return statut;
	}

	public void setStatut(Statut statut) {
		this.statut = statut;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}


		
	} 
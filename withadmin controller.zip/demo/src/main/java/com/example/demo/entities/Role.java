package com.example.demo.entities;

public enum Role {
    ADMIN,
    EMPLOYEE
}


package com.crm.firstsprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstsprintApplicationTests {

	@Test
	void contextLoads() {
	}

}

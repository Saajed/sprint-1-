package jakarta.persistence;

public class Entity {

}

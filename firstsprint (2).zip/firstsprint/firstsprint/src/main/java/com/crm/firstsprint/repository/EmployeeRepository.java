package com.crm.firstsprint.repository;

import com.crm.firstsprint.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Long> { }

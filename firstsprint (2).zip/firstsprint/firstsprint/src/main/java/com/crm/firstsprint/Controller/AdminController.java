package com.crm.firstsprint.Controller;

import com.crm.firstsprint.model.Admin;
import com.crm.firstsprint.model.Employee;
import com.crm.firstsprint.model.Client;
import com.crm.firstsprint.Service.AdminService;
import com.crm.firstsprint.Service.EmployeeService;
import com.crm.firstsprint.Service.ClientService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {

    private final AdminService adminService;
    private final EmployeeService employeeService;
    private final ClientService clientService;

    public AdminController(AdminService adminService, EmployeeService employeeService, ClientService clientService) {
        this.adminService = adminService;
        this.employeeService = employeeService;
        this.clientService = clientService;
    }

    // 1️⃣ Récupérer tous les employés (accessible uniquement par l'admin)
    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }

    // 2️⃣ Supprimer un employé
    @DeleteMapping("/employees/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
    }

    // 3️⃣ Modifier un employé
    @PutMapping("/employees/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        return employeeService.updateEmployee(id, employee);
    }

    // 4️⃣ Récupérer tous les clients
    @GetMapping("/clients")
    public List<Client> getAllClients() {
        return clientService.getAllClients();
    }

    // 5️⃣ Assigner un client à un employé
    @PutMapping("/assign-client/{employeeId}/{clientId}")
    public Employee assignClientToEmployee(@PathVariable Long employeeId, @PathVariable Long clientId) {
        return employeeService.assignClientToEmployee(employeeId, clientId);
    }
}

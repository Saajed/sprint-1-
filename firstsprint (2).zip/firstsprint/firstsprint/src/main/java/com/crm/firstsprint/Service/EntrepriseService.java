package com.crm.firstsprint.Service;


import com.crm.firstsprint.repository.EntrepriseRepository;
import com.crm.firstsprint.repository.ClientRepository;
import org.springframework.stereotype.Service;


@Service
public class EntrepriseService {

    private final EntrepriseRepository entrepriseRepository;
    private final ClientRepository clientRepository;

    public EntrepriseService(EntrepriseRepository entrepriseRepository, ClientRepository clientRepository) {
        this.entrepriseRepository = entrepriseRepository;
        this.clientRepository = clientRepository;
    }

    
}

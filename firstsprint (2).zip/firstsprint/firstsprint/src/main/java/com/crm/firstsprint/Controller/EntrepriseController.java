package com.crm.firstsprint.Controller;

import com.crm.firstsprint.Service.EntrepriseService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/entreprises")
public class EntrepriseController {

    private final EntrepriseService entrepriseService;

    public EntrepriseController(EntrepriseService entrepriseService) {
        this.entrepriseService = entrepriseService;
    }


    
}

package com.crm.firstsprint.repository;


import com.crm.firstsprint.model.Form;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FormRepository extends JpaRepository<Form, Long> {
    List<Form> findByClientId(Long clientId);
}


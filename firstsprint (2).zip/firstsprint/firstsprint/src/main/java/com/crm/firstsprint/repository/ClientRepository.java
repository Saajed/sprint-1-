package com.crm.firstsprint.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.crm.firstsprint.model.Client;

import java.util.List;
import java.util.Optional;

public interface ClientRepository extends JpaRepository<Client, Long> {
    Optional<Client> findByEmail(String email);

	List<Client> findAll();

	Optional<Client> findById(Long id);

	Client save(Client client);

	void deleteById(Long id);
}

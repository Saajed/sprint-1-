package com.crm.firstsprint.Controller;

import com.crm.firstsprint.Service.ClientService;

import org.springframework.boot.autoconfigure.integration.IntegrationProperties.RSocket.Client;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/clients")
public class ClientController {

    private final ClientService clientService;

    public ClientController(ClientService clientService) {
        this.clientService = clientService;
    }

    // FIND clients
    @GetMapping
    public List<Client> getAllClients() {
        return clientService.getAllClients();
    }

    // FIND client par son ID
    @GetMapping("/{id}")
    public Optional<Client> getClientById(@PathVariable Long id) {
        return clientService.getClientById(id);
    }

    // FIND client par email
    @GetMapping("/email/{email}")
    public Optional<Client> findByEmail(@PathVariable String email) {
        return clientService.findByEmail(email);
    }

    // ADD client
    @PostMapping
    public Client createClient(@RequestBody Client client) {
        return clientService.createClient(client);
    }

    // 5️⃣ Modifier  client
    @PutMapping("/{id}")
    public Client updateClient(@PathVariable Long id, @RequestBody Client updatedClient) {
        return clientService.updateClient(id, updatedClient);
    }

    // DELETE client
    @DeleteMapping("/{id}")
    public void deleteClient(@PathVariable Long id) {
        clientService.deleteClient(id);
    }
}

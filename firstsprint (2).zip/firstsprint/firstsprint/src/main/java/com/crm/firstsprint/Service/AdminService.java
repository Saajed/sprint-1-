package com.crm.firstsprint.service;

import com.crm.firstsprint.model.Admin;
import com.crm.firstsprint.repository.AdminRepository;
import org.springframework.stereotype.Service;

@Service
public class AdminService {
    private final AdminRepository adminRepository;

    public AdminService(AdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }
}

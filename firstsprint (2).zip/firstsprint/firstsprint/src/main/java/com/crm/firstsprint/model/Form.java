package com.crm.firstsprint.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter 
@Setter
@ToString
@Builder
@Table(name = "form")
public class Form {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime dateDeCreation;
    private LocalDateTime dateDerniereModification;
    private String but;
    
    @Enumerated(EnumType.STRING)
    private Etat string ; 

    @ManyToOne
    @JoinColumn(name = "client_id", nullable = false)
    private Client client;

    public Form() {
        this.dateDeCreation = LocalDateTime.now();
        this.dateDerniereModification = LocalDateTime.now();
    }

    public Form(String but, Client client) {
        this.dateDeCreation = LocalDateTime.now();
        this.dateDerniereModification = LocalDateTime.now();
        this.but = but;
        this.client = client;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getDateDeCreation() { return dateDeCreation; }
    public void setDateDeCreation(LocalDateTime dateDeCreation) { this.dateDeCreation = dateDeCreation; }

    public LocalDateTime getDateDerniereModification() { return dateDerniereModification; }
    public void setDateDerniereModification(LocalDateTime dateDerniereModification) { 
        this.dateDerniereModification = dateDerniereModification; 
    }

    public String getBut() { return but; }
    public void setBut(String but) { this.but = but; }

    public Client getClient() { return client; }
    public void setClient(Client client) { this.client = client; }
}


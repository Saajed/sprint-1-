package com.crm.firstsprint.repository;

import com.crm.firstsprint.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> { }

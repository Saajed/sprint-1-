package com.crm.firstsprint.model;

public enum Etat {
    ENCOURS,
    VALIDE ,
    NONVALIDE
}


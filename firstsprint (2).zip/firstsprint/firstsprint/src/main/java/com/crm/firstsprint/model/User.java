package com.crm.firstsprint.model;


import java.util.Date;

import jakarta.persistence.*;
import lombok.*;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter 
@Setter
@ToString
@Builder

@Inheritance(strategy = InheritanceType.JOINED)
public  class User {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nom;
    private String prenom;
    private String email;
    private Date dateNaissance;
    private String fonction;
    
    @Enumerated(EnumType.STRING)
    private Role string  ;
    

}

package com.crm.firstsprint.service;

import com.crm.firstsprint.model.Employee;
import com.crm.firstsprint.model.Client;
import com.crm.firstsprint.repository.EmployeeRepository;
import com.crm.firstsprint.repository.ClientRepository;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final ClientRepository clientRepository;

    public EmployeeService(EmployeeRepository employeeRepository, ClientRepository clientRepository) {
        this.employeeRepository = employeeRepository;
        this.clientRepository = clientRepository;
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    public Employee createEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public Employee updateEmployee(Long id, Employee updatedEmployee) {
        return employeeRepository.findById(id).map(employee -> {
            employee.setNom(updatedEmployee.getNom());
            employee.setPrenom(updatedEmployee.getPrenom());
            employee.setEmail(updatedEmployee.getEmail());
            employee.setFonction(updatedEmployee.getFonction());
            return employeeRepository.save(employee);
        }).orElseThrow(() -> new RuntimeException("Employee not found"));
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    // 📌 **Méthode pour assigner un client à un employé**
    public Employee assignClientToEmployee(Long employeeId, Long clientId) {
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employé non trouvé"));
        Client client = clientRepository.findById(clientId)
                .orElseThrow(() -> new RuntimeException("Client non trouvé"));

        employee.getAssignedClients().add(client);
        return employeeRepository.save(employee);
    }
}

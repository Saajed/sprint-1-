package com.crm.firstsprint.model;

public enum Role {
    ADMIN,
    EMPLOYEE
}


package com.example.demo.services;
import com.example.demo.entities.Admin;
import com.example.demo.repository.AdminRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class AdminService {
@Autowired
    private  AdminRepository adminRepository;
    
    
}
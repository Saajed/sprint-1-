package com.example.demo.services;

import com.example.demo.entities.Employee;
import com.example.demo.entities.User;
import com.example.demo.repository.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServices {

    @Autowired
    private UserRepository EmployeeRepository;

    public List<User> getAllEmployees() {
        return EmployeeRepository.findAll();
    }

    public Optional<User> getEmployeeById(Long id) {
        return EmployeeRepository.findById(id);
    }

    public Employee saveEmployee(Employee employee) {
        return EmployeeRepository.save(employee);
    }

    public void deleteEmployee(Long id) {
        EmployeeRepository.deleteById(id);
    }
}
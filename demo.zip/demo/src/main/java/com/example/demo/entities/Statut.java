package com.example.demo.entities;

public enum Statut {
    ENCOURS,
    VALIDE ,
    NONVALIDE
}


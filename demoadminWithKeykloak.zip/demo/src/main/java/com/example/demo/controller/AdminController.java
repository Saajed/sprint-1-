package com.example.demo.controller;

import com.example.demo.entities.Employee;
import com.example.demo.entities.Statut;
import com.example.demo.services.AdminService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200") //  Angular access only
@RequestMapping("/admin")
@AllArgsConstructor
public class AdminController {

    @Autowired
    private AdminService adminService;

    // Ajouter un employé
    @PostMapping("/employees")
    public Employee addEmployee(@RequestBody Employee employee) {
        return adminService.addEmployee(employee);
    }

    // Modifier un employé
    @PutMapping("/employees/{id}")
    public Employee updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails) {
        return adminService.updateEmployee(id, employeeDetails);
    }

    // Consulter la liste des employés
    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        return adminService.getAllEmployees();
    }

    // Consulter le statut d'un formulaire
    @GetMapping("/form-status/{formId}")
    public String getFormStatus(@PathVariable Long formId) {
        return adminService.getFormStatus(formId);
    }
    
 // Modifier le statut d'un formulaire
    @PutMapping("/update-form-status/{formId}")
    public String updateFormStatus(@PathVariable Long formId, @RequestParam Statut statut) {
        return adminService.updateFormStatus(formId, statut);
    }


    // Assigner un client à un employé après validation du formulaire
    @PostMapping("/assign/{employeeId}/{clientId}/{formId}")
    public String assignClientToEmployee(@PathVariable Long employeeId, 
                                         @PathVariable Long clientId, 
                                         @PathVariable Long formId) {
        return adminService.assignClientToEmployee(employeeId, clientId, formId);
    }
}

package com.example.demo.entities;

import jakarta.persistence.*;

import lombok.*;


@NoArgsConstructor
@AllArgsConstructor
@Getter 
@Setter 
@ToString

@Entity 
@DiscriminatorValue("ADMIN")
public class Admin extends User {

}

package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Form;


import java.util.List;

public interface FormRepository extends JpaRepository<Form, Long> {
    List<Form> findByClientId(Long clientId);
}

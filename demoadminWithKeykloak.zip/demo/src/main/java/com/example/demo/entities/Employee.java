package com.example.demo.entities;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter 
@Setter
@ToString
@DiscriminatorValue("EMPLOYEE")
public class Employee extends User {

    @ManyToMany
    @JoinTable(
        name = "employee_client",
        joinColumns = @JoinColumn(name = "employee_id"),
        inverseJoinColumns = @JoinColumn(name = "client_id")
    )
    private List<Client> assignedClients;

	public List<Client> getAssignedClients() {
		return assignedClients;
	}

	public void setAssignedClients(List<Client> assignedClients) {
		this.assignedClients = assignedClients;
	} 
    
}
